import numpy as np
import pandas as pd
import h5py

f_taxi = h5py.File('taxi_data.h5','r')
f_taxi.keys()
print([key for key in f_taxi.keys()])

f_graph= h5py.File('all_graph.h5','r')
f_graph.keys()
print([key for key in f_graph.keys()])
taxi_graph = f_graph['dis_tt'][:]

taxi_drop = np.expand_dims(f_taxi['taxi_drop'][:], axis=-1)
taxi_pick = np.expand_dims(f_taxi['taxi_pick'][:], axis=-1)

print(taxi_drop[taxi_drop==0].shape, taxi_pick[taxi_pick==0].shape)

taxi_demand = np.concatenate([taxi_drop, taxi_pick], axis=-1)
# np.savez('NYC_TAXI.npz', data=taxi_demand)
datas = np.load('NYC_TAXI.npz')
print(datas.files)
print(datas['data'])
print(datas['data'].shape)

# np.savetxt("NYC_TAXI.csv", taxi_graph, delimiter=",")
A = pd.read_csv("NYC_TAXI.csv", header=None).values.astype(np.float32)
print(A.shape)
print(A)


